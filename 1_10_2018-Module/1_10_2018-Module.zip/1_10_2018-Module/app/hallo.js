let data = {
    name: function(prefix){
        return prefix + "Welt";
    }
};

module.exports = data;